const express = require('express')
const mysql = require('mysql');
const multer = require('multer');
const path = require('path');
const app = express();

app.set('view engine', 'ejs');

app.use(express.static('public'));

app.use(express.urlencoded({ extended: true }));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'music_player'
});

db.connect(err => {
    if (err) throw err;
    console.log('Connected to MySQL');
});

const storage = multer.diskStorage({
    destination: './public/uploads/',
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

app.get('/', (req, res) => {
    const query = `SELECT * FROM music`;
    db.query(query, (err, songs) => {
        if (err) throw err;
        const playlistQuery = `SELECT * FROM playlist`;
        db.query(playlistQuery, (err, playlists) => {
            if (err) throw err;
            res.render('index', { songs, playlists });
        });
    });
});

app.post('/add-music', upload.single('musicfile'), (req, res) => {
    const { title, playlist_id } = req.body;
    const filename = req.file.filename;
    const query = `INSERT INTO music (title, filename, playlist_id) VALUES (?, ?, ?)`;
    db.query(query, [title, filename, playlist_id || null], (err) => {
        if (err) throw err;
        res.redirect('/');
    });
});

app.post('/delete-music/:id', (req, res) => {
    const query = `DELETE FROM music WHERE id = ?`;
    db.query(query, [req.params.id], (err) => {
        if (err) throw err;
        res.redirect('/');
    });
});

app.get('/search', (req, res) => {
    const { title } = req.query;
    const query = `SELECT * FROM music WHERE title LIKE ?`;
    db.query(query, [`%${title}%`], (err, songs) => {
        if (err) throw err;
        res.render('index', { songs, playlists: [] });
    });
});

app.post('/add-playlist', (req, res) => {
    const { name } = req.body;
    const query = `INSERT INTO playlist (name) VALUES (?)`;
    db.query(query, [name], (err) => {
        if (err) throw err;
        res.redirect('/');
    });
});

app.get('/playlist/:id', (req, res) => {
    const query = `SELECT * FROM music WHERE playlist_id = ?`;
    db.query(query, [req.params.id], (err, songs) => {
        if (err) throw err;
        res.render('playlist', { songs });
    });
});

app.listen(9000, () => {
    console.log('Server running on port 9000');
});
